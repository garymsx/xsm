module.exports = class XsmImport {
    constructor() {
        this.uri = null;
        this.path = null;
        this.import = null;
    }
}
