# SCOPEの意味

## keyword.control

